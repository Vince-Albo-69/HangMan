import java.util.Scanner;
/**
 * Write a description of class qa here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class HanMan
{
    static int count = 0;
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Enther phrase");
        String phrase = in.nextLine();
        phrase = phrase.toLowerCase();
        String under = "";
        int count = 0;
        for(int i = 0; i< phrase.length(); i++)
        {
            if (phrase.charAt(i) == ' ')
            {
                under += " ";

            }
            else
            {
                under += "_";

            }
        }
        System.out.println('\u000c');
        char[] answer = under.toCharArray();
        System.out.println(answer);
        while (underscoreCheck(answer) && count < 6)
        {
            System.out.println("Enther a character: ");
            String guess1 = in.next().toLowerCase();
            char guess = guess1.charAt(0);
            boolean right = false;
            for(int i = 0; i< phrase.length(); i++)
            {
                if (phrase.charAt(i) == guess)
                {
                    answer[i] = guess;
                    right = true;
                    
                }

            }
            if(right == false)
            {
                System.out.println("Wrong answer");
                count ++;

                if (count == 1) {
                    System.out.println("Your Wrong And Stupid");
                    System.out.println("   ____________");
                    System.out.println("   |          _|_");
                    System.out.println("   |         /   \\");
                    System.out.println("   |        |     |");
                    System.out.println("   |         \\_ _/");
                    System.out.println("   |");
                    System.out.println("   |");
                    System.out.println("   |");
                    System.out.println("___|___");
                }
                else if (count == 2) {
                    System.out.println("Your Wrong And Stupid");
                    System.out.println("   ____________");
                    System.out.println("   |          _|_");
                    System.out.println("   |         /   \\");
                    System.out.println("   |        |     |");
                    System.out.println("   |         \\_ _/");
                    System.out.println("   |           |");
                    System.out.println("   |           |");
                    System.out.println("   |");
                    System.out.println("___|___");
                }
                else if (count == 3) {
                    System.out.println("Your Wrong And Stupid");
                    System.out.println("   ____________");
                    System.out.println("   |          _|_");
                    System.out.println("   |         /   \\");
                    System.out.println("   |        |     |");
                    System.out.println("   |         \\_ _/");
                    System.out.println("   |           |");
                    System.out.println("   |           |");
                    System.out.println("   |          /  ");
                    System.out.println("___|___      /   ");
                }
                else if (count == 4) {
                    System.out.println("Your Wrong And Stupid");
                    System.out.println("   ____________");
                    System.out.println("   |          _|_");
                    System.out.println("   |         /   \\");
                    System.out.println("   |        |     |");
                    System.out.println("   |         \\_ _/");
                    System.out.println("   |           |");
                    System.out.println("   |           | ");
                    System.out.println("   |          / \\");
                    System.out.println("___|___      /   \\");
                }
                else if (count == 5) {
                    System.out.println("Your Wrong And Stupid");
                    System.out.println("   ____________");
                    System.out.println("   |          _|_");
                    System.out.println("   |         /   \\");
                    System.out.println("   |        |     |");
                    System.out.println("   |         \\_ _/");
                    System.out.println("   |         --|");
                    System.out.println("   |        /  | ");
                    System.out.println("   |          / \\");
                    System.out.println("___|___      /   \\");
                }
                else if (count == 6) {
                    System.out.println("GAME OVER! You're retarded");
                    System.out.println("   ____________");
                    System.out.println("   |          _|_");
                    System.out.println("   |         /   \\");
                    System.out.println("   |        |     |");
                    System.out.println("   |         \\_ _/");
                    System.out.println("   |          _|_");
                    System.out.println("   |         / | \\");
                    System.out.println("   |          / \\ ");
                    System.out.println("___|___      /   \\");
                    System.out.println("GAME OVER! The phrase was: " + phrase);
                }
            }
            
            System.out.println(answer);
        }
    }

    public static boolean underscoreCheck(char[] u)
    {
        for(char c: u)
        {
            if(c == '_')
            {
                return true;
            }
        }
        return false;
    }
    

}

